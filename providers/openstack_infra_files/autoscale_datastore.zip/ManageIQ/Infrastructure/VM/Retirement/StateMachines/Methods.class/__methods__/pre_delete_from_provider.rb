#
# Description: This method is a placeholder for retirement and runs prior to deleting the VM from the provider.
#
