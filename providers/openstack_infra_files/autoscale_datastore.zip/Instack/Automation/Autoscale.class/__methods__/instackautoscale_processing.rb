#
# CFME Automate Method: ServiceFlex_AddToService
#
# by Josh Carter & Kevin Morey
#
# Notes: This method MUST be ran after the PostProvision state in the provisioning StateMachine
#
# This method preforms the following:
# 1. Look up the parent service by ws_values[:serviceflex_service_id] to get the service object
# 2. Add newly provisioned vm to the parent service
# 3. Decrement parent service tag serviceflex_pending by 1
# 4. Increment parent service serviceflex_current tag by 1
# 5. Add custom attribute on the provisioned VM as to why it was provisioned. I.e. event driven or manually flexed
# 6. Tag vm with serviceflex_monitor
#
# Required inputs:
# $evm.root['miq_provision'], ws_values[:serviceflex_service_id], ws_values[:serviceflex_monitor],
#
###################################
begin
  # Method for logging
  def log(level, message)
    @method = 'InstackAutoscale_Processing'
    $evm.log(level, "#{@method}: #{message}")
  end
  
  log(:info, "CFME Autoscaling Method Started")

  # Get cluster
  cluster = $evm.root['ems_cluster']
  raise "Cluster object not found" if cluster.nil?
  log(:info, "Inspecting cluster object: <#{cluster.inspect}>")

  # Get Ems
  ems = cluster.ext_management_system
  
  # Get current number of compute hosts
  compute_hosts_count = ems.hosts.select{ |x| x.name.include?('(NovaCompute)')}.count
  
  # Get orchestration stack
  stack = ems.orchestration_stacks.first
  
  # Scale up by one host if free hosts are available, Nodes that are powered off are free
  if ems.hosts.select{|x| x.power_state == 'off'}.count > 0
    # There are free nodes, lets scale +1 compute host
    compute_hosts_count += 1    
    log(:info, "Autoscaling to #{compute_hosts_count}")  	
  	stack.raw_update_stack({:parameters => [{"name" => "compute-1::count", "value" => compute_hosts_count.to_s }]})
  else
    log(:warn, "Not enough free hosts for autoscale")
  end
  
end
